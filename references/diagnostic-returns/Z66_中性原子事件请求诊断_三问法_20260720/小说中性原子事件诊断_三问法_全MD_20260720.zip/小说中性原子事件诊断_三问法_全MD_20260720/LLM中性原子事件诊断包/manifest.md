# 原文件：manifest.json

> 来源路径：`manifest.json`  
> 转换说明：原内容未重排，放入 `json` 代码块；原始文件另存于同批归档。

````json
{
  "package": "LLM中性原子事件诊断包",
  "source_request": "default_ch0003_完整请求体.md",
  "chapter": 3,
  "recommended_event_count": 14,
  "validation": "PASS: 14 条事件，结构与 anchor_id 机械检查通过。",
  "files": [
    {
      "path": "01_附件1逐字诊断.md",
      "bytes": 13484,
      "sha256": "d66ef229acc79cf7d038e18e4ebdca101336307d92f357c7014430db85ae381c"
    },
    {
      "path": "02B_接口支持时可替换的严格response_format.json",
      "bytes": 7796,
      "sha256": "861ef110c0f93dc893b13a716a9dedfd2f621a89a6005d416d5a5570b547bb14"
    },
    {
      "path": "02_修正版请求体_第3章可直接发送.json",
      "bytes": 37119,
      "sha256": "55436f0158dca96e6d273dff4145a36de53a3fa759118f18319df6b86d9b9552"
    },
    {
      "path": "03_每处改动与理由.md",
      "bytes": 3608,
      "sha256": "e6ecad22cba098314b1f97499c3159c702841e6d5e5b63dc20dcbd6b7879f831"
    },
    {
      "path": "04_第3章完整抽取结果.json",
      "bytes": 7081,
      "sha256": "800302342dee12a9712c952b8928192a7139baf4dff900e4d1b9fa0a81893d05"
    },
    {
      "path": "05_第3章逐条抽取说明.md",
      "bytes": 11703,
      "sha256": "72cfd2559886db87867f5655d0ac92c0039bb98f71c35a3b189499479a71a7a6"
    },
    {
      "path": "06_现役10条输出逐条归因.md",
      "bytes": 6438,
      "sha256": "d47d8df4305117f6edba6cb57a6c19c885fe82ddb5b36890a09ded9896785a32"
    },
    {
      "path": "07_改动优先级与收益判断.md",
      "bytes": 2843,
      "sha256": "edd555754bbe5ce3a92f9c8587558a5b8a8c559a6aa8bed9fdacb0c12befd019"
    },
    {
      "path": "08_一次API调用能否保证.md",
      "bytes": 3603,
      "sha256": "0ffb8e5f19eeaa33d410cb0e520fc6d90a1316cf8596bf47593ccc4c1f6b27aa"
    },
    {
      "path": "09_验收指标与回归测试.md",
      "bytes": 3031,
      "sha256": "0034ab844ad816579cccdf7bbe6dba48b9aabc7b2e357f2aafac8eaec5f26354"
    },
    {
      "path": "10_本地实施步骤.md",
      "bytes": 2219,
      "sha256": "ac1a851649e71116b93a9ade589a5098097cfc97165569f2223fd1b4cab10237"
    },
    {
      "path": "README.md",
      "bytes": 3014,
      "sha256": "fb2f677dbf29564765f5660f2a2da1686291d996d3952c36ddbc2ca98d1c7ff8"
    },
    {
      "path": "appendix/供料统计.json",
      "bytes": 651,
      "sha256": "298b974ceee8cd8b96a875ed9b141ba426691bd1e944d9b68cc60e45534330df"
    },
    {
      "path": "appendix/机械校验回执.txt",
      "bytes": 63,
      "sha256": "a4758c6d5a4cda5cb38654eb71c821fc1ffe17793c5f989bb707186c93115519"
    },
    {
      "path": "appendix/现役模型可见请求体.json",
      "bytes": 24257,
      "sha256": "6a8bd34cbed865d74034f143149266ebaeab5d0cd095495d2fa768d4902810b0"
    },
    {
      "path": "appendix/现役第3章落盘事件池.json",
      "bytes": 3518,
      "sha256": "52b3fa82ba683667ac8609cd17807e467dfa2bf12575e2c5f864c90e99d37a47"
    },
    {
      "path": "appendix/第3章冻结证据目录.json",
      "bytes": 24298,
      "sha256": "2a5ca23bba5092e3faa41711fcc4fe57303e92e8c65ca31f3b9f1ee368ee8e85"
    },
    {
      "path": "appendix/第3章连续正文.txt",
      "bytes": 9923,
      "sha256": "96f5e17cbec15433b5d00bef18912eb39710ad67962e3716bca37203d4c06288"
    },
    {
      "path": "appendix/资料来源与限制.md",
      "bytes": 512,
      "sha256": "caaaf691e71cedde53b68f930d8bb8b6dc1b1f89d756cb4934ee624dea531ee6"
    },
    {
      "path": "appendix/附件1原始请求体.md",
      "bytes": 47888,
      "sha256": "fa1c65ad259161cfc17c5d3bc82fd0a5523461ee04df1065035938a5631506a4"
    },
    {
      "path": "appendix/附件1模型可见消息逐行文本.md",
      "bytes": 2427,
      "sha256": "2c1f4a37094864c57ad35fa534b2be8cf7e881736762835be78aa1afb2c00f89"
    },
    {
      "path": "tools/README.md",
      "bytes": 508,
      "sha256": "0c4a2672b6c401ebfc10d330e7bdbf7f3e9f612cbfea97688d0f7784539e32e9"
    },
    {
      "path": "tools/event_output.schema.json",
      "bytes": 6248,
      "sha256": "c8ba74ed3a269ee1fc41053fc1b6c562d074c591bbbbe288a6e0bbe8300e5b53"
    },
    {
      "path": "tools/validate_event_output.py",
      "bytes": 3994,
      "sha256": "eb7de3dbc335cf9f314fb2f40656e92bef6f81ecd799a1e936a67c71460a8494"
    }
  ]
}
````

来源：Codex
