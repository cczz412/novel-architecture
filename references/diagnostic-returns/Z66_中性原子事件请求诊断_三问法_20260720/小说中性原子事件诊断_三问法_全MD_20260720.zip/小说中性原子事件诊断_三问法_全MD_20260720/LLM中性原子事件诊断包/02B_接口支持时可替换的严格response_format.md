# 原文件：02B_接口支持时可替换的严格response_format.json

> 来源路径：`02B_接口支持时可替换的严格response_format.json`  
> 转换说明：原内容未重排，放入 `json` 代码块；原始文件另存于同批归档。

````json
{
  "response_format": {
    "type": "json_schema",
    "json_schema": {
      "name": "neutral_atomic_events",
      "strict": true,
      "schema": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "schema_version",
          "chapter",
          "events"
        ],
        "properties": {
          "schema_version": {
            "const": "z-event-v1"
          },
          "chapter": {
            "const": 3
          },
          "events": {
            "type": "array",
            "items": {
              "type": "object",
              "additionalProperties": false,
              "required": [
                "event_id",
                "event",
                "anchors"
              ],
              "properties": {
                "event_id": {
                  "type": "string",
                  "pattern": "^EV-C0003-[0-9]{2}$"
                },
                "event": {
                  "type": "string",
                  "minLength": 12
                },
                "anchors": {
                  "type": "array",
                  "minItems": 1,
                  "items": {
                    "type": "object",
                    "additionalProperties": false,
                    "required": [
                      "anchor_id"
                    ],
                    "properties": {
                      "anchor_id": {
                        "type": "string",
                        "enum": [
                          "E0001",
                          "E0002",
                          "E0003",
                          "E0004",
                          "E0005",
                          "E0006",
                          "E0007",
                          "E0008",
                          "E0009",
                          "E0010",
                          "E0011",
                          "E0012",
                          "E0013",
                          "E0014",
                          "E0015",
                          "E0016",
                          "E0017",
                          "E0018",
                          "E0019",
                          "E0020",
                          "E0021",
                          "E0022",
                          "E0023",
                          "E0024",
                          "E0025",
                          "E0026",
                          "E0027",
                          "E0028",
                          "E0029",
                          "E0030",
                          "E0031",
                          "E0032",
                          "E0033",
                          "E0034",
                          "E0035",
                          "E0036",
                          "E0037",
                          "E0038",
                          "E0039",
                          "E0040",
                          "E0041",
                          "E0042",
                          "E0043",
                          "E0044",
                          "E0045",
                          "E0046",
                          "E0047",
                          "E0048",
                          "E0049",
                          "E0050",
                          "E0051",
                          "E0052",
                          "E0053",
                          "E0054",
                          "E0055",
                          "E0056",
                          "E0057",
                          "E0058",
                          "E0059",
                          "E0060",
                          "E0061",
                          "E0062",
                          "E0063",
                          "E0064",
                          "E0065",
                          "E0066",
                          "E0067",
                          "E0068",
                          "E0069",
                          "E0070",
                          "E0071",
                          "E0072",
                          "E0073",
                          "E0074",
                          "E0075",
                          "E0076",
                          "E0077",
                          "E0078",
                          "E0079",
                          "E0080",
                          "E0081",
                          "E0082",
                          "E0083",
                          "E0084",
                          "E0085",
                          "E0086",
                          "E0087",
                          "E0088",
                          "E0089",
                          "E0090",
                          "E0091",
                          "E0092",
                          "E0093",
                          "E0094",
                          "E0095",
                          "E0096",
                          "E0097",
                          "E0098",
                          "E0099",
                          "E0100",
                          "E0101",
                          "E0102",
                          "E0103",
                          "E0104",
                          "E0105",
                          "E0106",
                          "E0107",
                          "E0108",
                          "E0109",
                          "E0110",
                          "E0111",
                          "E0112",
                          "E0113",
                          "E0114",
                          "E0115",
                          "E0116",
                          "E0117",
                          "E0118",
                          "E0119",
                          "E0120",
                          "E0121",
                          "E0122",
                          "E0123",
                          "E0124",
                          "E0125",
                          "E0126",
                          "E0127",
                          "E0128",
                          "E0129",
                          "E0130",
                          "E0131",
                          "E0132",
                          "E0133",
                          "E0134",
                          "E0135",
                          "E0136",
                          "E0137",
                          "E0138",
                          "E0139",
                          "E0140",
                          "E0141",
                          "E0142",
                          "E0143",
                          "E0144",
                          "E0145",
                          "E0146",
                          "E0147",
                          "E0148",
                          "E0149",
                          "E0150",
                          "E0151",
                          "E0152",
                          "E0153",
                          "E0154",
                          "E0155",
                          "E0156",
                          "E0157",
                          "E0158",
                          "E0159",
                          "E0160",
                          "E0161",
                          "E0162",
                          "E0163",
                          "E0164",
                          "E0165",
                          "E0166",
                          "E0167",
                          "E0168",
                          "E0169",
                          "E0170",
                          "E0171",
                          "E0172",
                          "E0173",
                          "E0174",
                          "E0175"
                        ]
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
````

来源：Codex
