# 07_DOCX_可访问性审计

> 由 `07_DOCX_可访问性审计.json` 转成 Markdown，便于 Notion 上传。原文 JSON 如下。

```json
{
  "file": "/mnt/data/z78_output/01_事实句流水线三板块框架_完整报告_调查候选.docx",
  "counts": {
    "high": 0,
    "medium": 0,
    "low": 0
  },
  "findings": []
}
```
