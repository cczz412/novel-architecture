# 03_技巧卡_JSON_Schema_v0.2

> 由 `03_技巧卡_JSON_Schema_v0.2.json` 转成 Markdown，便于 Notion 上传。原文 JSON 如下。

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "事实句流水线技巧卡",
  "type": "object",
  "required": [
    "card_id",
    "name",
    "atomic_action",
    "primary_home",
    "when_to_use",
    "symptoms",
    "steps",
    "avoid",
    "examples",
    "linkage_requirements",
    "acceptance_tests",
    "preconditions",
    "schema_reads",
    "schema_writes",
    "conflicts"
  ],
  "properties": {
    "card_id": {
      "type": "string"
    },
    "name": {
      "type": "string"
    },
    "aliases": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "atomic_action": {
      "type": "string",
      "description": "一张卡只写一个可执行动作；复杂理论拆成多卡。"
    },
    "primary_home": {
      "type": "object",
      "required": [
        "block",
        "span",
        "bucket_id"
      ],
      "properties": {
        "block": {
          "enum": [
            "P1",
            "P2",
            "P3"
          ]
        },
        "span": {
          "enum": [
            "S1",
            "S2",
            "S3"
          ]
        },
        "bucket_id": {
          "type": "string",
          "pattern": "^P[123]-\\d{2}$"
        },
        "placement_role": {
          "type": [
            "string",
            "null"
          ]
        }
      },
      "additionalProperties": false
    },
    "secondary_links": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "when_to_use": {
      "type": "string"
    },
    "symptoms": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "preconditions": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "schema_reads": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "schema_writes": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "steps": {
      "type": "array",
      "items": {
        "type": "object",
        "required": [
          "author_action",
          "system_action",
          "visible_feedback"
        ],
        "properties": {
          "author_action": {
            "type": "string"
          },
          "system_action": {
            "type": "string"
          },
          "visible_feedback": {
            "type": "string"
          }
        }
      },
      "minItems": 1,
      "maxItems": 3
    },
    "avoid": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "examples": {
      "type": "array",
      "minItems": 1,
      "maxItems": 2,
      "items": {
        "type": "object",
        "required": [
          "book",
          "chapter",
          "anchors",
          "summary",
          "material_level"
        ],
        "properties": {
          "book": {
            "type": "string"
          },
          "chapter": {
            "type": "string"
          },
          "anchors": {
            "type": "array",
            "minItems": 1,
            "items": {
              "type": "string"
            }
          },
          "summary": {
            "type": "string"
          },
          "material_level": {
            "type": "string"
          },
          "note": {
            "type": "string"
          }
        },
        "additionalProperties": false
      }
    },
    "linkage_requirements": {
      "type": "object",
      "properties": {
        "P1": {
          "type": "string"
        },
        "P2": {
          "type": "string"
        },
        "P3": {
          "type": "string"
        }
      },
      "required": [
        "P1",
        "P2",
        "P3"
      ],
      "additionalProperties": false
    },
    "acceptance_tests": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "conflicts": {
      "type": "array",
      "items": {
        "type": "string"
      }
    }
  },
  "additionalProperties": false
}
```
